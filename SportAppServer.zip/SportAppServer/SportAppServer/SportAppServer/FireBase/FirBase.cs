﻿namespace SportAppServer.FireBase
{
    public class FirBase
    {

    }
}

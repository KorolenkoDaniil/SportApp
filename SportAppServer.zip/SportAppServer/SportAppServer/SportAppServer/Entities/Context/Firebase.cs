﻿using FirebaseAdmin;
using FirebaseAdmin.Messaging;

namespace SportAppServer.Entities.Context
{
    public class Firebase
    {

    }
}
